from django.apps import AppConfig


class BrightmailConfig(AppConfig):
    name = 'brightMail'
